#include <stdio.h>
int main()
{
float r, C, PI = 3.1415926;
printf("Enter radius: ");
scanf("%f", &r);
C = 2*PI*r;
printf("Circumference = %f\n", C);
return 0;
}
