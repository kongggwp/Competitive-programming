#include <stdio.h>
int main()
{ int i, T=2, R;

for (i=1;i<=12; i++) {
R = i * T;
printf("%d x %d = %d\n", i,T,R);
}
return 0;
}
