#include<stdio.h>
int main()
{
    float a,b;
    printf("Base : ");scanf("%f",&a);
    printf("Height : ");scanf("%f",&b);
    printf("%f",0.5*a*b);
}
