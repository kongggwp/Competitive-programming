#include<stdio.h>
int main()
{
    printf("Input X : ");
    float x;
    scanf("%f",&x);
    float y=x*x+8*x+4;
    printf("%f",y);
}
