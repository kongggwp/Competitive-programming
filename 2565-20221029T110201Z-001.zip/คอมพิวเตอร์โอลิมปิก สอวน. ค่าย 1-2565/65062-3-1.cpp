#include <bits/stdc++.h>
using namespace std;
int main(){
    float x,sum=0;
    for(int i=0 ; i<10 ; i++)
    {
        cin >> x;
        sum +=x;
    }
    cout << sum/10;
}
