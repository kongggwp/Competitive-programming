#include <stdio.h>
int main()
{
	int a=0.5*10*14;
	printf("%d",a);
}
