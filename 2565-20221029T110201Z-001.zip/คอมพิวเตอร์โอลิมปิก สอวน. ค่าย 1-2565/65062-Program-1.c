#include <stdio.h>
int main()
{ 
int X, Y, sum;

printf("Enter X: "); scanf("%d", &X);
printf("Enter Y: "); scanf("%d", &Y);
sum = X + Y;
printf("sum = %d\n", sum);

return 0;
}
