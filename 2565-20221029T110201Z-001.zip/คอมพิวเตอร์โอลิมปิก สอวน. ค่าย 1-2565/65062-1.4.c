#include<stdio.h>
int main()
{
    printf("Input : ");
    int x;
    scanf("%d",&x);
    x=x-543;
    printf("%d",x);
}
